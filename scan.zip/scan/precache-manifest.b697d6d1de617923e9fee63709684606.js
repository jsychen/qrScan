self.__precacheManifest = [
  {
    "revision": "6a91f31672ec10d61fd8",
    "url": "styles.css"
  },
  {
    "url": "main.14df4d22cd974a023174.bundle.js"
  }
];